<?php
header ("Location: ../index.php");    // en caso de intentar a este directorio, me regresa al home.
?>